"""Lifecycle and dispatch tests using a fake backend, never a fake weight claim.

The fake isolates session ownership: it proves load-once/release behavior while
real numerical parity remains a separate official-checkpoint gate.
Reads: bandit_infer.api.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pytest
import torch

from bandit_infer import BanditSession
from bandit_infer import api
from bandit_infer.checkpoints import ChecksumError


class FakeBackend:
    def infer(self, audio: np.ndarray, sample_rate: int) -> dict[str, np.ndarray]:
        return {"speech": audio, "music": audio, "effects": audio}


def install_runtime(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> dict[str, int]:
    checkpoint = tmp_path / "model.ckpt"
    checkpoint.write_bytes(b"model")
    calls = {"loads": 0}
    monkeypatch.setattr(api, "resolve_checkpoint", lambda *args, **kwargs: checkpoint)
    monkeypatch.setattr(api, "resolve_device", lambda value: torch.device("cpu"))
    def load(*args: object, **kwargs: object) -> FakeBackend:
        calls["loads"] += 1
        return FakeBackend()
    monkeypatch.setattr(api, "load_runtime_backend", load)
    return calls


def test_ready_only_no_reload_release_close_and_context(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    calls = install_runtime(monkeypatch, tmp_path)
    session = BanditSession()
    with pytest.raises(RuntimeError, match="requires a ready"):
        session.infer(np.zeros(8), sample_rate=44100)
    assert session.load().load() is session
    session.infer(np.zeros(8), sample_rate=44100)
    session.infer(np.zeros(8), sample_rate=44100)
    assert calls["loads"] == 1
    session.release()
    assert session.status == "released"
    session.load()
    assert calls["loads"] == 2
    session.close()
    session.close()
    assert session.status == "closed"
    with pytest.raises(RuntimeError, match="closed"):
        session.load()


def test_family_selection_is_not_an_alias() -> None:
    assert BanditSession("v1-mus64-l1snr").spec.family == "v1"
    assert BanditSession("v2-multi").spec.family == "v2"
    with pytest.raises(ValueError, match="belongs to family"):
        BanditSession("v1-mus64-l1snr", family="v2")


def test_framework_backend_argument_is_not_public_api() -> None:
    with pytest.raises(TypeError, match="unexpected keyword argument"):
        BanditSession("v1-mus64-l1snr", **{"backend": "torch"})
    with pytest.raises(TypeError, match="unexpected keyword argument"):
        api.separate(np.zeros(8), sample_rate=44100, **{"backend": "torch"})


def test_custom_checkpoint_cache_matches_loaded_bytes(monkeypatch, tmp_path):
    checkpoint = tmp_path / "manual" / "weights.ckpt"
    digest = hashlib.sha256(b"custom model").hexdigest()
    session = BanditSession(
        device="cpu", checkpoint_path=checkpoint, checkpoint_sha256=digest,
        weights_dir=tmp_path / "unused-cache",
    )
    info = session.cache_info()
    assert info["path"] == checkpoint
    assert not info["exists"] and not info["verified"]
    assert not checkpoint.parent.exists()
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"custom model")
    seen = []

    def load(spec, path, device):
        seen.append(path)
        return FakeBackend()

    monkeypatch.setattr(api, "load_runtime_backend", load)
    assert session.cache_info()["verified"]
    session.load()
    assert seen == [checkpoint]
    assert session.cache_info()["path"] == seen[0]
    assert not (tmp_path / "unused-cache").exists()
    checkpoint.write_bytes(b"corrupt")
    assert not session.cache_info()["verified"]
    session.release()
    with pytest.raises(ChecksumError):
        session.load()
